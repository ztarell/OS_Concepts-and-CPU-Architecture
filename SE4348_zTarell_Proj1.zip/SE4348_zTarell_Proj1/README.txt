1. Writ-up: Summary of the Project
2. Memory.java
3. CPU.java

Requirements of the program:

1. All files (CPU.java, Memory.java, and all sample files) must be in the same folder.
2. Compile the CPU.java and Memory.java by executing javac CPU.java and javac Memory.java
3. Run by execute command java CPU [integer] [filename], where [integer] is a timer value for the CPU. 
It must be greater than or equal to 2 to work, otherwise the program will display error message and exit. 
The [fileName] is the name of the sample file that the user wishes to run.
It must include the extension of the type (ex: sample1.txt).

PLEASE NOTE:

Running the program works with [TIMER] first and then [FILENAME] second.
I understand this is backward from the requirements but I didn't realize it until project was almost written to complettion.
I realized I was having trouble printing the output files and couldn't get them to execute the correct output.
I explain more of this in the write-up (specifically the EXPERIENCE portion),
but didn't fix the [TIMER] [FILENAME] order due to unsuccessful attempts and causing more errors.
 