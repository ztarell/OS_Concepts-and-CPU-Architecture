
/** *
 * Zachary Tarell
 * zjt170000
 * SE 4348.003
 *
 * Project 1
 *
 * Class: CPU
 * Simulate the computer's CPU.
 * It has these registers:  PC, SP, IR, AC, X, Y.
 * It supports the instructions shown on problem document (also listed in the instruct method later)
 * It runs the user program at address 0.
 * Instructions are fetched into the IR from memory.  The operand is fetched into a local variable.
 * Each instruction is executed before the next instruction is fetched.
 * The program ends when the End instruction is executed.  The 2 processes should end at that time.
 */
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class CPU {

    private static int pc, sp, ir, ac, x, y;                    // registers
    private static int mode;                                    // access mode
    public static final int USER_MODE = 0, KERNEL_MODE = 1;     // available modes
    private static int timer;                                   // timer value for instruction counts
    private static int instructionCount;                        // count how many instructions has been performed
    private static boolean allowInterrupt;                      // check to see if the interrupt is enabled or disabled
    private static PrintWriter printWriter;
    private static Scanner scanner;
    private static Process process;

    public static void main(String[] args) {

        int time = 0;
        String filename = "";
	int ir = 0;

        // check the argument: a filename and a number
        if (args.length != 2) {
            // wrong number of argument
            System.out.println("Error: Invalid argument list for CPU.");
            System.exit(-1);
        } else{
            try {
                time = Integer.parseInt(args[0]);

                if(time < 2) {
                    System.out.println("Error: Invalid argument list for CPU.");
                    System.exit(-1);
                }

                filename = args[1];
            }
            catch(NumberFormatException e) {
                System.out.println("Error: Invalid argument list for CPU.");
                System.exit(-1);
            }
        }

        // connect to an external program using Process - Memory
        try {
            Runtime rt = Runtime.getRuntime();

            // Memory initializes itself by running the program file
            process = rt.exec(String.format("java Memory %s", filename));
            InputStream inputStream = process.getInputStream();
            OutputStream outputStream = process.getOutputStream();
            printWriter = new PrintWriter(outputStream);
            scanner = new Scanner(inputStream);

            // initialize
            pc = sp = ir = ac = x = y = 0;
            sp = 999;
            mode = USER_MODE;
            allowInterrupt = true;
            timer = time;

            // fetch instruction and execute
            fetch(process);

            // close all streams and process
            printWriter.close();
            inputStream.close();
            outputStream.close();
            process.waitFor();

        } catch (Throwable t) {
            t.printStackTrace();
        }

    }

    /**
     * *
     * method: fetch load instructions from memory into ir one by one and
     * process each of them before fetching another instruction
     */
    private static void fetch(Process process) {
        // the program ends at ir = 50
        while (ir != 50) {

            // error condition
            if (ir == Integer.MAX_VALUE || pc == Integer.MAX_VALUE || sp == Integer.MAX_VALUE) {
                break;
            }

            // read the instruction at pc
            read(pc++);

            // load instruction to ir
            ir = parseInt();

            // error conditions
            if (ir == Integer.MAX_VALUE || pc == Integer.MAX_VALUE || sp == Integer.MAX_VALUE) {
                break;
            }

            // get the operand for the appropriate instructions and process
            if (ir <= 5 || ir == 7 || ir == 9 || (ir >= 20 && ir <= 23) || ir == 31) {
                read(pc++);
                int operand = parseInt();
                instruct(ir, operand);
            } else {
                instruct(ir);
            }
        }
    }

    /**
     * *
     * method: instruct perform the instructions and manipulate values of the
     * registers and memory
     *
     * @param tokens: operand(s) of the instruction
     */
    private static void instruct(int... tokens) {
        int ir = 0, // first location of the tokens is for ir
                operand = 1;    // second location of the tokens is for operand
System.out.println(tokens[0]);
System.out.flush();
        // perform instructions
        switch (tokens[ir]) {
            case 0: //do nothing
                break;
            case 1:     // load value into AC
                ac = tokens[operand];
                break;
            case 2:     // load the value at the address into AC
                read(tokens[operand]);
                ac = parseInt();
                break;
            case 3:     // Load the value from the address found in the given address into the AC
                read(tokens[operand]);
                int location = scanner.nextInt();
                read(location);
                ac = parseInt();
                break;
            case 4:     // Load the value at (address+X) into the AC
                read(tokens[operand] + x);
                ac = parseInt();
                break;
            case 5:     // Load the value at (address+Y) into the AC
                read(tokens[operand] + y);
                ac = parseInt();
                break;
            case 6:     // Load from (Sp+X) into the AC
                read(sp + x);
                ac = parseInt();
                break;
            case 7:     // Store the value in the AC into the address
                write(tokens[operand], ac);
                break;
            case 8:     // Gets a random int from 1 to 100 into the AC
                ac = (int) (Math.random() * 100) + 1;
                break;
            case 9:     // put port
                if (tokens[operand] == 1) {
                    System.out.print(ac);
                } else {
                    System.out.print((char) ac);
                }
System.out.print(ac); 
                break;
            case 10:    // Add the value in X to the AC
                ac += x;
                break;
            case 11:    // Add the value in Y to the AC
                ac += y;
                break;
            case 12:    // Subtract the value in X from the AC
                ac -= x;
                break;
            case 13:    // Subtract the value in Y from the AC
                ac -= y;
                break;
            case 14:    // Copy the value in the AC to X
                x = ac;
                break;
            case 15:    // Copy the value in X to the AC
                ac = x;
                break;
            case 16:    //Copy the value in the AC to Y
                y = ac;
                break;
            case 17:    // Copy the value in Y to the AC
                ac = y;
                break;
            case 18:    // Copy the value in AC to the SP
                sp = ac;
                break;
            case 19:    // Copy the value in SP to the AC
                ac = sp;
                break;
            case 20:    // jump to the address
                pc = tokens[operand];
                break;
            case 21:    // Jump to the address only if the value in the AC is zero
                if (ac == 0) {
                    pc = tokens[operand];
                }
                break;
            case 22:    // Jump to the address only if the value in the AC is not zero
                if (ac != 0) {
                    pc = tokens[operand];
                }
                break;
            case 23:    // Push return address onto stack, jump to the address
                pushStack("User", pc);
                pc = tokens[operand];
                break;
            case 24:    // Pop return address from the stack, jump to the address
                popStack("User");
                pc = parseInt();
                break;
            case 25:    // Increment the value in X
                x++;
                break;
            case 26:    // Decrement the value in X
                x--;
                break;
            case 27:    // Push AC onto user stack
                if (mode == USER_MODE) {
                    pushStack("User", ac);
                    peekIndex("User");
                    sp = parseInt();
                } else {
                    pushStack("System", ac);
                    peekIndex("System");
                    sp = parseInt();
                }
                break;
            case 28:    // Pop from stack into AC
                if (mode == USER_MODE) {
                    popStack("User");
                    ac = parseInt();
                    peekIndex("User");
                    sp = parseInt();
                } else {
                    popStack("System");
                    ac = parseInt();
                    peekIndex("System");
                    sp = parseInt();
                }
                break;
            case 29:    // Perform system call
                if (allowInterrupt) {
                    handleInterrupt(false);
                }
                break;
            case 30:    // Return from system call
                returnFromInterrupt();
                break;
            case 31:    //Compute AC mod VAL, store in AC
                ac = ac % tokens[operand];
                break;
            case 32:    //Call address in AC register
                 System.out.print(ac);
            case 50:    // End execution
                break;
            default:    // safeguard
                break;

        }   // end switch

        // timer interrupt
        if (allowInterrupt && ++instructionCount >= timer) {
            handleInterrupt(true);
            instructionCount = 0;
        }
    }

    /**
     * *
     * method: read format of the read command send through pipe to the Memory
     * to read
     *
     * @param location: index of the memory to read
     */
    private static void read(int location) {
        printWriter.printf("read %d %d\n", location, mode);
        printWriter.flush();
    }

    /**
     * *
     * method: write format of the write command send through pipe to the Memory
     * to write
     *
     * @param location: index of the memory to write
     * @param data: integer to write to the memory
     */
    private static void write(int location, int data) {
        printWriter.printf("write %d %d %d\n", location, data, mode);
        printWriter.flush();
    }

    /**
     * *
     * method: pushStack format of the pushStack(whichOne) methods command to
     * push new data onto stack
     *
     * @param whichStack: user or system
     * @param value: what to push to the stack
     */
    private static void pushStack(String whichStack, int value) {
        printWriter.printf("push%s %d\n", whichStack, value);
        printWriter.flush();
    }

    /**
     * *
     * method: popStack format of the popStackk(whichOne) methods command to pop
     * data from the stacks
     *
     * @param whichStack: user or system
     */
    private static void popStack(String whichStack) {
        printWriter.printf("pop%s\n", whichStack);
        printWriter.flush();
    }

    /**
     * *
     * method: parseInt Parse input from scanner to an integer and return If
     * cannot parse to an integer, it means the stream from the Memory is an
     * error message. Print it to the screen and exit.
     *
     * @return integer
     */
    private static int parseInt() {
        if (scanner.hasNextInt()) {
            return scanner.nextInt();
        } else {
            int count = 0;

            // print out the line till the word exit (break at this point)
            while (scanner.hasNext()) {
                String word = scanner.next();
                if (word.equals("exit")) {
                    break;
                }
                System.out.print(word.concat(" "));
            }
            System.out.println();
            System.exit(-1);

            return Integer.MAX_VALUE;
        }
    }

    /**
     * *
     * method: handleInterrupt perform interrupt handling when an interrupt
     * occurs Save sp and pc to system stack A timer interrupt should cause
     * execution at address 1000. The int instruction should cause execution at
     * address 1500. Interrupts is disabled to avoid nested execution.
     *
     * @param isTimerInterrupt: flag of which kind of interrupt
     */
    private static void handleInterrupt(boolean isTimerInterrupt) {
        mode = KERNEL_MODE;
        allowInterrupt = false;

        // push sp and pc onto the stack
        pushStack("System", sp);
        pushStack("System", pc);

        peekIndex("System");
        sp = parseInt();

        if (isTimerInterrupt) {
            // system stack
            pc = 1000;
        } else {
            // user stack
            pc = 1500;
        }
    }

    /**
     * *
     * method: returnFromInterrupt return to the place before the interrupt
     * happened restore pc & sp from stack enable interrupt again switch mode
     */
    private static void returnFromInterrupt() {

        // pop pc
        popStack("System");
        pc = parseInt();

        // pop sp
        popStack("System");
        sp = parseInt();

        // allow interrupts and change to user mode
        allowInterrupt = true;
        mode = USER_MODE;
    }

    /**
     * *
     * method: peekIndex format of the command to get the index of the top of
     * the stakcs
     *
     * @param whichStack: user or system
     */
    private static void peekIndex(String whichStack) {
        printWriter.printf("peekIndex%s\n", whichStack);
        printWriter.flush();
    }

}
