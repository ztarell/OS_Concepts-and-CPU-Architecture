
/** *
 * Zachary Tarell
 * zjt170000
 * SE4348.003
 *
 * Project 1
 *
 * Class: Memory
 * Simulate the computer's main memory.
 * It consists of 2000 integer entries, 0-999 for the user program, 1000-1999 for system code.
 * The user stack resides at the end of user memory and grows down toward address 0.
 * The system stack resides at the end of system memory and grows down toward address 0.
 * There is no hardware enforcement of stack size.
 * The user program cannot access system memory (exits with error message).
 * It supports two operations:
 *      read(address) -  returns the value at the address (including pushing stacks)
 *      write(address, data) - writes the data to the address (including popping stacks)
 * Memory will initialize itself by reading a program file (the name of the sample file is hardcoded)
 */

import java.io.*;
import java.util.*;

public class Memory {

    private static final int MEMORY_SIZE = 2000;           // size of the memory
    private static int[] array = new int[MEMORY_SIZE];     // memory
    private static final int SPLIT = 999;                  // 0-999 for programs, 1000-1999 for system
    private static int userStack = 999;                    // the stack section of the user memory
    private static int systemStack = 1999;                 // the stack section of the system memory

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Invalid argument list");
            System.exit(-1);
        }

        initializeMemory(args[0]);
        Scanner scanner = new Scanner(System.in);
        String command = scanner.nextLine();
        String[] tokens = command.split("[\\s+\\n]");
        //System.err.println(tokens[1]);
        int address = 0, mode = 0, data = 0;

        // perform commands
        do {
            if (command.contains("read")) {
                address = Integer.parseInt(tokens[1]);
                mode = Integer.parseInt(tokens[2]);
                read(address, mode);
            } else if (command.contains("write")) {
                address = Integer.parseInt(tokens[1]);
                data = Integer.parseInt(tokens[2]);
                write(address, data);
            } else if (command.contains("pushSystem")) {
                data = Integer.parseInt(tokens[1]);
                pushSystemStack(data);
            } else if (command.contains("pushUser")) {
                data = Integer.parseInt(tokens[1]);
                pushUserStack(data);
            } else if (command.contains("popSystem")) {
                popSystemStack();
            } else if (command.contains("popUser")) {
                popUserStack();
            } else if (command.contains("peekIndexSystem")) {
                peekIndexSystemStack();
            } else if (command.contains("peekIndexUser")) {
                peekIndexUserStack();
            } else if (command.contains("print")) {
                printMemory();
            }

            command = scanner.nextLine();
            tokens = command.split("[\\s+,\\n]");

        } while (!command.isEmpty());

    }

    /**
     * *
     * method: initializeMemory initialize the memory by reading from a file
     *
     * @param fileName: the name of the input file
     */
    private static void initializeMemory(String fileName) {
        int current = 0;
        int c = 0;

        /*
         * read file line by line
         * breaks each line into tokens, using whitespace(s) as a delimiter
         * put the first token into the next element of the memory
         * print error message to the screen if cannot read the file
         */
        try {
            Scanner scanner = new Scanner(new File(fileName));

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                c = line.indexOf("//");
                line = line.substring(0,c);
                String[] tokens = line.split("\\s+");
                
                // set new current in jump statement
                if (tokens[0].contains(".")) {
                    current = Integer.parseInt(tokens[0].substring(1));
                } // lines of instructions
                else if (!tokens[0].isEmpty() && Character.isDigit(tokens[0].charAt(0))) {
                    array[current++] = Integer.parseInt(tokens[0]);
                }
                // skip all blank lines and comment lines
            }
        } catch (FileNotFoundException e) {
            System.out.printf("Error: cannot find the file \"%s\" exit\n", fileName);
        }
    }

    /**
     * *
     * method: printMemory print out the indices and its data skip through
     * series of 0 (empty locations) NOTE: this method is only for testing
     * purpose it does not get called during the execution of the project
     */
    public static void printMemory() {
        System.out.println("Index:\t\t\tData");

        for (int index = 0; index < MEMORY_SIZE; index++) {
            // don't print series of 0's (empty indices)
            if ((index == 0 && array[index] == 0)
                    || (index > 0 && array[index] == 0 && array[index - 1] == 0)) {
                continue;
            }

            System.out.printf("%4d\t\t\t%d\r\n", index, array[index]);
        }

        System.out.println();
    }

    /**
     * *
     * method: read read the memory at a specific address and print it out
     *
     * @param address: the index of the array to read
     * @param mode: user or kernel mode
     */
    public static void read(int address, int mode) {
        if (!isValidAccess(address, mode)) {
            System.out.printf("Invalid access of location %d from user mode. exit\n", address);
        } else {
            System.out.println(array[address]);
        }
    }

    /**
     * *
     * method: write write data to a specific address of the memory
     *
     * @param address: index of the array
     * @param data: an integer to put into the array
     */
    public static void write(int address, int data) {
        array[address] = data;
    }

    /**
     * *
     * method: isValidAccess check to see if the current user has permission to
     * access the block of memory (access system memory from user mode)
     *
     * @param address: index of memory to access
     * @param mode: user or kernel mode
     * @return true if accessible, false if not
     */
    private static boolean isValidAccess(int address, int mode) {
        return !(mode == 0 && address > SPLIT);
    }

    /**
     * *
     * method: pushUserStack put new data on top of the stack
     *
     * @param data: integer to put to the stack
     */
    private static void pushUserStack(int data) {
        if (userStack < 0) {
            System.out.println("Error: User stack overflow. exit");
        } else {
            array[userStack--] = data;
        }
    }

    /**
     * *
     * method: popUserStack remove and print the top of the stack
     */
    private static void popUserStack() {
        // throw error if try to pop empty stack
        if (userStack > SPLIT) {
            System.out.println("Error: User stack is empty. exit");
        } // pop stack
        else {
            int value = array[++userStack];
            array[userStack] = 0;
            System.out.printf("%d\n", value);
        }
    }

    /**
     * *
     * method: peekIndexUserStack print the index of the top element in the
     * stack
     */
    private static void peekIndexUserStack() {
        System.out.printf("%d\n", userStack);
    }

    /**
     * *
     * method: peekIndexSystemStack print the index of the top element in the
     * stack
     */
    private static void peekIndexSystemStack() {
        System.out.printf("%d\n", systemStack);
    }

    /**
     * *
     * method: pushSystemStack push new element onto the system stack
     *
     * @param data: integer to put into the stack
     */
    private static void pushSystemStack(int data) {
        if (systemStack < 0) {
            System.out.println("Error: System stack overflow. exit");
        } else {
            array[systemStack--] = data;
        }
    }

    /**
     * *
     * method: popSystemStack pop the top of the system stack update the system
     * stack pointer check for operation errors print the top of the stack
     */
    private static void popSystemStack() {
        // check underflow system stack
        if (systemStack >= MEMORY_SIZE) {
            System.out.println("Error: System stack is empty. exit");
        } // pop system stack
        else {
            int value = array[++systemStack];
            array[systemStack] = 0;
            System.out.printf("%d\n", value);
        }
    }

}
